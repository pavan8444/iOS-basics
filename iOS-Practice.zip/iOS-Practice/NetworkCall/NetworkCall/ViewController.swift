//
//  ViewController.swift
//  NetworkCall
//
//  Created by Pavan on 13/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController  {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var countries = [[String:String]]()
    var filteredCountries = [[String:String]]()
    
    var isSearch : Bool?
    
   // var resultSearchController = UISearchController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        isSearch = false

        self.getDataUsingURLSession()
//             self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getData() {
//        let url = URL(string: "http://services.groupkt.com/country/get/all")
        Alamofire.request("http://services.groupkt.com/country/get/all").responseJSON { (response) in
//            print(response)
            self.countries = ((response.result.value as! [String:Any])["RestResponse"] as! [String : Any])["result"] as! [[String:String]]
            self.tableView.reloadData()
            let filteredArray = self.countries.filter{$0["name"] == "India"}
            print(filteredArray)
        }
//        Alamofire.request(url, method: .get, parameters: nil, encoding: nil, headers: nil).responseJSON { (response) in
        
//        }
    }
    
    func getDataUsingURLSession() {
        let url = URL(string: "http://services.groupkt.com/country/get/all")
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do {
                let stringData = try JSONSerialization.jsonObject(with: data!, options: [])
                self.countries = ((stringData as! [String:Any])["RestResponse"] as! [String : Any])["result"] as! [[String:String]]
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
            } catch let error as Error {
                print(error.localizedDescription)
            }
            
            
        }
        task.resume()
    }

}

extension ViewController : UISearchBarDelegate {
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        let searchStr = searchBar.text!
        filteredCountries = self.countries.filter{($0["name"]?.contains(searchStr))!}
        
        if filteredCountries.count > 0 {
            isSearch = true            
        } else {
            isSearch = false
        }
        self.tableView.reloadData()
        
        //self.tableView.reloadData()
        //print(filteredArray)
    }
    
//    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//        return true
//    }
//
}


extension ViewController: UITableViewDelegate , UITableViewDataSource {
   
//    func updateSearchResults(for searchController: UISearchController) {
//        filteredCountries.removeAll(keepingCapacity: false)
//
//        let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text!)
//        let array = (countries as NSArray).filtered(using: searchPredicate)
//        filteredCountries = (array as? [String])!
//
//        self.tableView.reloadData()
//    }
//
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.isSearch == true) {
            return self.filteredCountries.count
        }
        else {
            return self.countries.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "networkCell", for: indexPath)
        var aNetwork = [String:String]()
        
        if (self.isSearch == true) {
            aNetwork = self.filteredCountries[indexPath.row]
        } else {
            aNetwork = self.countries[indexPath.row]
        }
        
        cell.textLabel?.text = aNetwork["name"]
        return cell
        
        
//        func updateSearchResultsForsearchController( searchController: UISearchController)
//        {
//
//            filteredCountries.removeAll(keepingCapacity: false)
//if let searchText = searchController.searchBar.text {
 //       filteredData = searchText.isEmpty ? data : data.filter({(dataString: String) -> Bool in
   //         return dataString.rangeOfString(searchText, options: .CaseInsensitiveSearch) != nil
 //       })
        
//        tableView.reloadData()
//    }
//            let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text!)
//           let array = (countries as NSArray).filtered(using: searchPredicate)
//            filteredCountries = (array as? [String])!
//
//           self.tableView.reloadData()
//        }
    }
   
    
}
