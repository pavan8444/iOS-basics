//
//  ViewController.swift
//  MyCalculator
//
//  Created by pavan chowdary on 06/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fistValue: UITextField!
    @IBOutlet weak var secondValue: UITextField!
    @IBOutlet weak var resultLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addBtn(_ sender: Any) {
        let first = Int(self.fistValue.text!)
        let second = Int(self.secondValue.text!)
        if first != nil && second != nil {
            let add: Int = (first! + second!)
            self.resultLbl.text = ("Result is \(add) ")
        } else{
            self.resultLbl.text = "Invalid input !!"
        }
        
    }
    @IBAction func subBtn(_ sender: Any) {
        let first = Int(self.fistValue.text!)
        let second = Int(self.secondValue.text!)
        if first != nil && second != nil {
            let sub: Int = (first! - second!)
            self.resultLbl.text = (" Result is \(sub) ")
        } else{
            self.resultLbl.text = "Invalid input !!"
        }
    }
    
    @IBAction func mulBtn(_ sender: Any) {
        let first = Int(self.fistValue.text!)
        let second = Int(self.secondValue.text!)
        if first != nil && second != nil {
            let mul: Int = (first! * second!)
            self.resultLbl.text = ("Result is \(mul) ")
        } else{
            self.resultLbl.text = "Invalid input !!"
        }
    }
}

