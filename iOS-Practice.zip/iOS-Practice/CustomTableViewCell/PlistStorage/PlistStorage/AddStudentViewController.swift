//
//  AddStudentViewController.swift
//  PlistStorage
//
//  Created by Gangadhar on 19/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class AddStudentViewController: UIViewController {

    @IBOutlet weak var nameTextField : UITextField!
    @IBOutlet weak var courseTextField : UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
                
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func saveStudent() {
        let resoursePath = Bundle.main.path(forResource: "StudentDetails", ofType: "plist")
        
        let documentPath = self.documentsDirectory().appending("/StudentDetails.plist")
        print(documentPath)
        let fileManager = FileManager()
        if !fileManager.fileExists(atPath: documentPath) {
            do {
                try fileManager.copyItem(atPath: resoursePath!, toPath: documentPath)
            } catch let error as NSError {
                print(error.description)
            }
        }
        
        if let data = try? Data(contentsOf: URL(fileURLWithPath: documentPath)) {
            if var result = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [[String: Any]] { // [String: Any] which ever it is
                print(result!)
                if self.nameTextField.text != "" && self.courseTextField.text != "" {
                    let newStudent = ["name":self.nameTextField.text!,"course":self.courseTextField.text!] as [String:Any]
                    result?.append(newStudent)
                    let resutltArray = NSMutableArray(array: result!)
                    resutltArray.write(toFile: documentPath, atomically: true)
                }
            }
        }
    }
    
    @IBAction func saveStudent(_ sender: Any) {
        self.saveStudent()
        if self.nameTextField.text != "" && self.courseTextField.text != "" {
            let newStudent : [String:String] = ["Name":self.nameTextField.text!, "Course":self.courseTextField.text!]
            NotificationCenter.default.post(name: NSNotification.Name("addNewStudent"), object: nil, userInfo: ["newStudent":newStudent])
            let alertController = UIAlertController(title: "Success", message: "New Student Added", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: { Void in
                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }  else{
            let alertController = UIAlertController(title: "Failed", message: "Please fill the Text Fields", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil )
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
    }
    }
    func documentsDirectory()->String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory,
                                                        .userDomainMask, true)
        let documentsDirectory = paths.first!
        return documentsDirectory
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
