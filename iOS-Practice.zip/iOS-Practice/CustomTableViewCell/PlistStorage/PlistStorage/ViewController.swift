//
//  ViewController.swift
//  PlistStorage
//
//  Created by Gangadhar on 19/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var studentsArray : [[String:Any]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.readPlist()
    }
    
    func readPlist() {
        
        let documentPath = self.documentsDirectory().appending("/StudentDetails.plist")
        let fileManager = FileManager()
        if !fileManager.fileExists(atPath: documentPath) {
            let resoursePath = Bundle.main.path(forResource: "StudentDetails", ofType: "plist")
            do {
                try fileManager.copyItem(atPath: resoursePath!, toPath: documentPath)
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
        
        //Using Swift
        let fileUrl = URL(fileURLWithPath: documentPath)
        if let data = try? Data (contentsOf: fileUrl) {
            if let result = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [[String: Any]] { // [String: Any] which ever it is
                print(result!)
                self.studentsArray = result
                self.tableView.reloadData()
            }
        }
        
/*
        //Using NSArray (Objective-c Style)
        let path = Bundle.main.path(forResource: "StudentDetails", ofType: "plist")
        let studentsArray = NSArray(contentsOfFile: path!)
        print(studentsArray!)
 */
    }
    
    func documentsDirectory()->String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory,
                                                        .userDomainMask, true)
        let documentsDirectory = paths.first!
        return documentsDirectory
    }


}
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 100
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.studentsArray?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentsCell", for: indexPath)
        let aStudent = self.studentsArray?[indexPath.row]
        
        cell.textLabel?.text = aStudent?["name"] as? String
        cell.detailTextLabel?.text = aStudent?["course"] as? String
        cell.accessoryType = .disclosureIndicator
        
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let alertController = UIAlertController(title: "", message: "Are you sure you want to delete?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (alert) in
            tableView.isEditing = false
        }
        // pop-up window for delete
        let yesAction = UIAlertAction(title: "Yes", style: .default) { (alert) in
            self.studentsArray?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .top)
        }
        // Alert actions
        
        alertController.addAction(yesAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
        self.tableView.reloadData()
    }
}

