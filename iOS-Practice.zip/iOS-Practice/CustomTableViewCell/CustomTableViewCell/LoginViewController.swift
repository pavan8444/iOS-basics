//
//  LoginViewController.swift
//  CustomTableViewCell
//
//  Created by pavan chowdary on 20/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func loginClicked(_ sender: Any) {
        UserDefaults.standard.set(1, forKey: "isLoggedIn")
        UserDefaults.standard.synchronize()
        let homeView = self.storyboard?.instantiateViewController(withIdentifier: "HomeView") as! ViewController
        let navigationController = UINavigationController(rootViewController: homeView)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = navigationController
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
