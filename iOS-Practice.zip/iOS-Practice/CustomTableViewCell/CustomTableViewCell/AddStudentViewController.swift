//
//  AddStudentViewController.swift
//  CustomTableViewCell
//
//  Created by pavan chowdary on 12/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class AddStudentViewController: UIViewController {


    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var courseTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "New Student"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // For Submiting a new student details need to pop-up that Success
    @IBAction func submitClicked(_ sender: Any) {
        if self.nameTextField.text != "" && self.courseTextField.text != "" {
            let newStudent : [String:String] = ["Name":self.nameTextField.text!, "Course":self.courseTextField.text!, "imageUrl":""]
            NotificationCenter.default.post(name: NSNotification.Name("addNewStudent"), object: nil, userInfo: ["newStudent":newStudent])
            let alertController = UIAlertController(title: "Success", message: "New Student Added", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: { Void in
                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
