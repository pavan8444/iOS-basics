//
//  ViewController.swift
//  CustomTableViewCell
//
//  Created by pavan chowdary on 12/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {

    @IBOutlet weak var tableView: UITableView!
    var studentArray: [[String:String]] = [["Name":"Pavan", "Course":"DotNet","imageURL":""],["Name":"Suresh", "Course":"Java","imageURL":""],["Name":"Rakesh", "Course":"iOS","imageURL":""]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.gotoAddNewStudent))
        self.navigationItem.rightBarButtonItem = rightBarButton
        self.title = "Students"
        
        let leftBarButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(self.logout))
        self.navigationItem.leftBarButtonItem = leftBarButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func gotoAddNewStudent() {
        let addStudentView = self.storyboard?.instantiateViewController(withIdentifier: "AddStudentView") as! AddStudentViewController
        self.navigationController?.pushViewController(addStudentView, animated: true)
        NotificationCenter.default.addObserver(self, selector: #selector(self.addNewStudent(_:)), name: NSNotification.Name("addNewStudent"), object: nil)
    }
    
    @objc func logout() {
        let loginView = self.storyboard?.instantiateViewController(withIdentifier: "LoginView") as! LoginViewController
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = loginView
        
        UserDefaults.standard.removeObject(forKey: "isLoggedIn")
        UserDefaults.standard.synchronize()
        
    }
    
    @objc func addNewStudent(_ notification:Notification) {
        let newStudent = notification.userInfo!["newStudent"] as! [String:String]
        self.studentArray.append(newStudent)
        self.tableView.reloadData()
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("addNewStudent"), object: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.studentArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath) as! CustomTableViewCell
        let astudent = studentArray[indexPath.row]
        cell.nameLbl.text = astudent["Name"]
        cell.courseLbl.text = astudent["Course"]
        cell.imgView.image = UIImage(named:"Logo")
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    //  maintaining table height of constant 100
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    // This func shows the data clearly in Details View controller page
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let  aStudent = studentArray[indexPath.row]
        let detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsView") as! DetailsViewController
        detailsView.studentData = aStudent
        self.navigationController?.pushViewController(detailsView, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    // Notification For deleting a row at HomeView or a view controller
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let alertController = UIAlertController(title: "", message: "Are you sure you want to delete?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (alert) in
            tableView.isEditing = false
        }
        // pop-up window for delete
        let yesAction = UIAlertAction(title: "Yes", style: .default) { (alert) in
            self.studentArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .top)
        }
        // Alert actions
        alertController.addAction(cancelAction)
        alertController.addAction(yesAction)
        
        self.present(alertController, animated: true, completion: nil)        
    }
}

