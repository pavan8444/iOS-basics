//
//  ViewController.swift
//  TableViewCell
//
//  Created by pavan chowdary on 10/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource {
    
  
    @IBOutlet weak var tableView: UITableView!
    
    var myArray = [["Name ","Course","Details","marks"],["Hello","Hi"]]
    var myDetail = [["Pavan","MPC","NA","98"],["Hi","Everyone"]]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return myArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = myArray[indexPath.section][indexPath.row]
        cell?.detailTextLabel?.text = myDetail[indexPath.section][indexPath.row] 
        return cell!
    }

}

