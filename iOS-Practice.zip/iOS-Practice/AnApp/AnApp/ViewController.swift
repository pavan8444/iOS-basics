//
//  ViewController.swift
//  AnApp
//
//  Created by Gangadhar on 06/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstValue: UITextField!
    @IBOutlet weak var secondValue: UITextField!
    @IBOutlet weak var lblResult: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: Any) {
        let first = Int(self.firstValue.text!)
        let second = Int(self.secondValue.text!)
        if first != nil && second != nil{
            self.lblResult.text = "Result is \(first! + second!)"
        }else{
            self.lblResult.text = "Invalid input!!!"
        }
    }

}

