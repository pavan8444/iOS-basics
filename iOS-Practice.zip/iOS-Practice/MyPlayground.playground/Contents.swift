import UIKit
var myString = "Hello, World!"
print(myString)

import UIKit
var str="Taran & Puju"
print(str)

var varA = 42
print(varA)

// varB is inferred to be of type Double
var varB = 3.14159
print(varB)

// varC is also inferred to be of type Double
var varC = 3 + 0.14159
print(varC)

//var varD=42
var D="This is Hello"
print(D)

var A = "Godzilla"
var B = 1000.00

print("Value of \(A) is more than \(B) millions")
