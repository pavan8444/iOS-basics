//
//  ViewController.swift
//  MyApp1
//
//  Created by Gangadhar on 06/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblResult: UILabel!
    @IBOutlet weak var firstValue: UITextField!
    @IBOutlet weak var secondValue: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: Any) {
        let val1 = Int(self.firstValue.text!)
        let val2 = Int(self.secondValue.text!)
        if val1 != nil && val2 != nil{
            lblResult.text = "Result is \(val1!+val2!)"
        }else{
            lblResult.text = "Invalid input"
        }
    }

}

