//
//  AddStudentViewController.swift
//  CustomTableView
//
//  Created by Gangadhar on 09/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class AddStudentViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var courseTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "New Student"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitClicked(_ sender: Any) {
        if self.nameTextField.text != "" && self.courseTextField.text != "" {
            let studentData = ["name" : self.nameTextField.text!, "course" : self.courseTextField.text!, "imgUrl":""]
            NotificationCenter.default.post(name: Notification.Name("addStudent"), object: nil, userInfo: ["userInfo":studentData])
            
            let alert = UIAlertController(title: "", message: "Student Added", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default){ (action) in
                self.nameTextField.text = ""
                self.courseTextField.text = ""
            }
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
