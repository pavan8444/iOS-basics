//
//  ViewController.swift
//  CustomTableView
//
//  Created by Gangadhar on 09/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var dataArray : [[String:String]] = [["name":"Ramesh", "course":"DotNet", "imgUrl":""], ["name":"Kishore", "course":"Java", "imgUrl":""], ["name":"Ravi", "course":"iOS", "imgUrl":""]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: Notification.Name("addStudent"), object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        
    func addStudent(_ notification:NSNotification) {
        self.dataArray.append(notification.userInfo?["userInfo"] as! [String : String])
        self.tableView.reloadData()
        NotificationCenter.default.removeObserver(self, name: Notification.Name("addStudent"), object: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        NotificationCenter.default.addObserver(self, selector: #selector(self.addStudent(_:)), name: Notification.Name("addStudent"), object: nil)
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomTableViewCell
        let aData = self.dataArray[indexPath.row]
        cell.nameLbl.text = aData["name"]
        cell.courseLbl.text = aData["course"]
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsView") as! DetailsViewController
        detailsView.studentDetails = self.dataArray[indexPath.row]
        self.navigationController?.pushViewController(detailsView, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "", message: "Are you sure? You want to delete.", preferredStyle: .alert)
        let action = UIAlertAction(title: "Yes", style: .default) { (action) in
            self.dataArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
        alert.addAction(action)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){ (action) in
            tableView.isEditing = false
        }
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
        
    }
    
}
