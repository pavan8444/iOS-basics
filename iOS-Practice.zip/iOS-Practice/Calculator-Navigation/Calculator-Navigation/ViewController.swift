//
//  ViewController.swift
//  Calculator-Navigation
//
//  Created by pavan chowdary on 07/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstBtn: UITextField!
    
    @IBOutlet weak var secondBtn: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true;
    }
    @IBAction func addBtn(_ sender: Any) {
        if self.firstBtn.text != "" && self.secondBtn.text != "" {
            let first = Int(self.firstBtn.text!)
            let second = Int(self.secondBtn.text!)
            if first != nil && second != nil {
                // let add = first + second
                let secondView = self.storyboard?.instantiateViewController(withIdentifier: "senderView") as! SecondViewController
                let result = String(format: "%d", first! + second!)
                secondView.result = result
                self.navigationController?.pushViewController(secondView, animated: true)
            }
        }
        
    }
    
    @IBAction func subPressed(_ sender: Any) {
        if self.firstBtn.text != "" && self.secondBtn.text != "" {
            let first = Int(self.firstBtn.text!)
            let second = Int(self.secondBtn.text!)
            if first != nil && second != nil {
                // let add = first + second
                let secondView = self.storyboard?.instantiateViewController(withIdentifier: "senderView") as! SecondViewController
                let result = String(format: "%d", first! - second!)
                secondView.result = result
                self.navigationController?.pushViewController(secondView, animated: true)
            }
        }
    }
    
    @IBAction func multiplyPressed(_ sender: Any) {
        if self.firstBtn.text != "" && self.secondBtn.text != "" {
            let first = Int(self.firstBtn.text!)
            let second = Int(self.secondBtn.text!)
            if first != nil && second != nil {
                // let add = first + second
                let secondView = self.storyboard?.instantiateViewController(withIdentifier: "senderView") as! SecondViewController
                let result = String(format: "%d", first! * second!)
                secondView.result = result
                self.navigationController?.pushViewController(secondView, animated: true)
            }
        }
    }
    @IBAction func dividePressed(_ sender: Any) {
        if self.firstBtn.text != "" && self.secondBtn.text != "" {
            let first = Int(self.firstBtn.text!)
            let second = Int(self.secondBtn.text!)
            if first != nil && second != nil {
                // let add = first + second
                let secondView = self.storyboard?.instantiateViewController(withIdentifier: "senderView") as! SecondViewController
                let result = String(format: "%d", first! / second!)
                secondView.result = result
                self.navigationController?.pushViewController(secondView, animated: true)
            }
        }
    }
}
       
    



