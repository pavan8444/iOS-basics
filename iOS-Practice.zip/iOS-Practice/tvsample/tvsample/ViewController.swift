import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTableView: UITableView!
    let myArray = [["1","2","3","4","5"],["1","2","3","4"],["1","2","3","4","5","6"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in myTableView: UITableView) -> Int {
        return 2//myArray.count
    }
    
    func myTableView(_ myTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray[section].count
    }
    
    func myTableView(_ myTableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "mycell")
        cell?.textLabel?.text = myArray[indexPath.section][indexPath.row]
        return cell!
    }
    
    
}
