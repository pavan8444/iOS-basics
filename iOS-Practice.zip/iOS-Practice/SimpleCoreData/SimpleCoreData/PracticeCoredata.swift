//
//  ViewController.swift
//  SimpleCoreData
//
//  Created by Pavan on 02/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var result : [Student]?
    
    override func viewDidLoad() {
        self.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        self.saveStudent()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.goToNewStudent))
        self.navigationItem.rightBarButtonItem = rightBarButton
        self.title = "Students"
        self.getStudents()

    }

    override func didReceiveMemoryWarning() {
        self.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func goToNewStudent (){
        let addStudentView = self.storyboard?.instantiateViewController(withIdentifier: "addNew") as! AddNewStudentViewController
        self.navigationController?.pushViewController(addStudentView, animated: true)
        NotificationCenter.default.addObserver(self, selector: #selector(self.addNewStudent(_:)), name: NSNotification.Name("addNewStudent"), object: nil)
    }
    
    @objc func addNewStudent(_ notification:Notification) {
        let newStudent = notification.userInfo!["newStudent"]
        self.result?.append(newStudent as! Student)
        self.tableView.reloadData()
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("addNewStudent"), object: nil)
    }
    func saveStudent() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Student", in: context)
        let newStudent = NSManagedObject(entity: entity!, insertInto: context)
        newStudent.setValue("Pavan", forKey: "name")
        newStudent.setValue("IOS", forKey: "course")
        newStudent.setValue("HIT", forKey: "college")
        newStudent.setValue("2014", forKey: "passedoutyear")
        
        do {
            try context.save()
        } catch  {
            
        }
    }
    
    @objc func getStudents() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        request.returnsDistinctResults = true
        do {
            result = try context.fetch(request) as? [Student]
           // print(result!)
            tableView.reloadData()
        } catch {
            
        }
    }
    
   extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (result?.count)!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        let student = result![indexPath.row]
        cell.textLabel?.text = student.name
        cell.detailTextLabel?.text = student.course
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let alertController = UIAlertController(title: "", message: "Are you sure you want to delete?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (alert) in
            tableView.isEditing = false
        }
        // pop-up window for delete
        let yesAction = UIAlertAction(title: "Yes", style: .default) { (alert) in
            self.result?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .top)
        }
        // Alert actions
        
        alertController.addAction(yesAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    


