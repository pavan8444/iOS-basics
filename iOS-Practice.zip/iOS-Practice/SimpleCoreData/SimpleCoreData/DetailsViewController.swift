//
//  DetailsViewController.swift
//  SimpleCoreData
//
//  Created by Pavan on 02/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {

    var sDetails = Student()
    
    @IBOutlet weak var courseTextField: UITextField!
    @IBOutlet weak var collegeTextField: UITextField!
    @IBOutlet weak var passedOutYearTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(self.editView))
        self.navigationItem.rightBarButtonItem = rightBarButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func editView() {
        self.enableView(enable: true)
    }
    
    func enableView(enable:Bool) {
        self.courseTextField.isEnabled = enable
        self.collegeTextField.isEnabled = enable
        self.passedOutYearTextField.isEnabled = enable
        self.saveButton.isEnabled = enable
    }
    
    @IBAction func saveStudentDetails(_ sender: Any) {
        self.enableView(enable: false)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
