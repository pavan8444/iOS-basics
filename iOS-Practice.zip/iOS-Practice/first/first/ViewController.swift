//
//  ViewController.swift
//  first
//
//  Created by Gangadhar on 05/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func myButton(_ sender: Any) {
        print(self.txtUserName.text!)
        print(self.txtPassword.text!)
    }


}

