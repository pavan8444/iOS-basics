//
//  ViewController.swift
//  BabyApp
//
//  Created by Gangadhar on 12/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfFirst: UITextField!
    @IBOutlet weak var tfSecond: UITextField!
    @IBOutlet weak var lblResult: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addClick(_ sender: Any) {
        let x = Int(self.tfFirst.text!)
        let y = Int(self.tfSecond.text!)
        if x != nil && y != nil{
            self.lblResult.text = "Result is \(x!+y!)"
        }else{
            self.lblResult.text = "Invalid input"
        }
    }

}

