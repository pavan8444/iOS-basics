//
//  AddStudentViewController.swift
//  PlistStorage
//
//  Created by Gangadhar on 19/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class AddStudentViewController: UIViewController {

    @IBOutlet weak var nameTextField : UITextField!
    @IBOutlet weak var courseTextField : UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.saveStudent()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func saveStudent() {
        let resoursePath = Bundle.main.path(forResource: "StudentDetails", ofType: "plist")
        
        let documentPath = self.documentsDirectory().appending("/StudentDetails.plist")
        print(documentPath)
        let fileManager = FileManager()
        if !fileManager.fileExists(atPath: documentPath) {
            do {
                try fileManager.copyItem(atPath: resoursePath!, toPath: documentPath)
            } catch let error as NSError {
                print(error.description)
            }
        }
        
        if let data = try? Data(contentsOf: URL(fileURLWithPath: documentPath)) {
            if var result = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [[String: Any]] { // [String: Any] which ever it is
                print(result!)
                let newStudent = ["name":self.nameTextField.text!,"course":self.courseTextField.text!] as [String:Any]
                result?.append(newStudent)
            }
        }
    }
    
    func documentsDirectory()->String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory,
                                                        .userDomainMask, true)
        let documentsDirectory = paths.first!
        return documentsDirectory
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
