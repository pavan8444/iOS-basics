//
//  ViewController.swift
//  PlistStorage
//
//  Created by Gangadhar on 19/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var studentsArray : [[String:Any]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.readPlist()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func readPlist() {
        
        //Using Swift
        if let fileUrl = Bundle.main.url(forResource: "StudentDetails", withExtension: "plist"),
            let data = try? Data(contentsOf: fileUrl) {
            if let result = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [[String: Any]] { // [String: Any] which ever it is
                print(result!)
                self.studentsArray = result
                self.tableView.reloadData()
            }
        }
/*
        //Using NSArray (Objective-c Style)
        let path = Bundle.main.path(forResource: "StudentDetails", ofType: "plist")
        let studentsArray = NSArray(contentsOfFile: path!)
        print(studentsArray!)
 */
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.studentsArray?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentsCell", for: indexPath)
        let aStudent = self.studentsArray?[indexPath.row]
        
        cell.textLabel?.text = aStudent?["name"] as? String
        cell.detailTextLabel?.text = aStudent?["course"] as? String
        
        return cell
    }
}

