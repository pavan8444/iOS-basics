//
//  ViewController.swift
//  PracticeCoreData
//
//  Created by Pavan on 05/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController  {
    
     var result : [Student]?
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.gotoAddNewStudent))
        self.navigationItem.rightBarButtonItem = rightBarButton
        self.title = "Employees"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getStudents()
    }
    
    
    @objc func gotoAddNewStudent() {
        let addStudentView = self.storyboard?.instantiateViewController(withIdentifier: "addNewDetail") as! AddNewDetails
        self.navigationController?.pushViewController(addStudentView, animated: true)
             //  NotificationCenter.default.addObserver(self, selector: #selector(self.Student(_:)), name: NSNotification.Name("Student"), object: nil)
    }
    
    func getStudents() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
//        let predicate = NSPredicate(format: "course contains[c] %@ AND name contains[c] %@", "iOS", "P")
//        request.predicate = predicate
        request.returnsDistinctResults = true
        do {
           result = try context.fetch(request) as? [Student]
            print(result!)
            self.tableView.reloadData()
        } catch let error as NSError {
            print(error.localizedDescription)
            
        }
    }
    @IBAction func searchFilter(_ sender: Any) {
        
    }
    

}
extension ViewController : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.result?.count)!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        let student = result![indexPath.row]
        cell.textLabel?.text = student.name
        cell.detailTextLabel?.text = student.course
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Print Here")
        let student = self.result![indexPath.row]
        let detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsView") as! DetailsViewController
        detailsView.studentsData = student
        self.navigationController?.pushViewController(detailsView, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
       return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let alertController = UIAlertController(title: "", message: "Are you sure you want to delete?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (alert) in
            tableView.isEditing = false
        }
        // pop-up window for delete
        let yesAction = UIAlertAction(title: "Yes", style: .default) { (alert) in
            self.result?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .top)
            let student = self.result![indexPath.row]
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            context.delete(student)
            
        }
        // Alert actions
        
        alertController.addAction(yesAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
       
    }
    
    
}

