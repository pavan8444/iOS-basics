//
//  DetailsViewController.swift
//  PracticeCoreData
//
//  Created by Pavan on 09/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {

    var studentsData = Student()
    
    @IBOutlet weak var courseTextField: UITextField!
    @IBOutlet weak var collegeTextField: UITextField!
    @IBOutlet weak var passedOutYearTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = studentsData.name
        
        let rightBarButton = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(self.editView))
        self.navigationItem.rightBarButtonItem = rightBarButton
        self.populateData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func populateData() {
        self.courseTextField.text = self.studentsData.course
        self.collegeTextField.text = self.studentsData.college!.name
        
    }
    
    @objc func editView() {
        self.enableView(enable: true)
    }
    
    func enableView(enable:Bool) {
        self.courseTextField.isEnabled = enable
        self.collegeTextField.isEnabled = enable
        self.passedOutYearTextField.isEnabled = enable
        self.saveButton.isEnabled = enable
    }
    
    @IBAction func saveStudentDetails(_ sender: Any) {
        self.enableView(enable: false)
        studentsData.course = self.courseTextField.text
        studentsData.college?.name = self.collegeTextField.text
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        do {
            try context.save()
        } catch {
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
