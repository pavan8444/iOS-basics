//
//  AddNewDetails.swift
//  PracticeCoreData
//
//  Created by Pavan on 08/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit
import CoreData

class AddNewDetails: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var courseTextField: UITextField!
    
    @IBOutlet weak var collegeTextField: UITextField!
    
    @IBOutlet weak var cityTextField: UITextField!
    
    
    var aCollege = College()
    var aCity = City()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
       super.viewWillAppear(animated)
       NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "selectedCollege"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "selectedCity"), object: nil)
    }
    
    @IBAction func submitPressed(_ sender: Any) {
        if self.nameTextField.text != "" && self.courseTextField.text != "" && self.collegeTextField.text != "" && self.cityTextField.text != "" {
            //            let newStudent : [String:String] = ["name":self.nameTextField.text!, "course":self.courseTextField.text!, "college":self.collegeTextField.text!, "passedoutyear": self.passedOutField.text!]
            
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "Student", in: context)
            let newStudent = NSManagedObject(entity: entity!, insertInto: context)
            newStudent.setValue(self.nameTextField.text!, forKey: "name")
            newStudent.setValue(self.courseTextField.text!, forKey: "course")        
            newStudent.setValue(self.aCity, forKey: "city")
            newStudent.setValue(self.aCollege, forKey: "college")
            do {
                try context.save()
            } catch  {
                
            }
            
            
            let alertController = UIAlertController(title: "Success", message: "New Student Details Saved", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: { Void in
                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }else{
            let alertController = UIAlertController(title: "Failed", message: "Please fill the Text Fields", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil )
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    @objc func showCollege(_ notification:Notification) {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "selectedCollege"), object: nil)
        
        self.aCollege = notification.userInfo!["college"] as! College
        self.collegeTextField.text = aCollege.name
    }
    
  @objc func showCity(_ notification:Notification){
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "selectedCity"), object: nil)
        self.aCity = notification.userInfo! ["city"] as! City
        self.cityTextField.text = aCity.name
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
   

}

extension AddNewDetails : UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == self.collegeTextField {
            let navCont = self.storyboard?.instantiateViewController(withIdentifier: "collegeNavController")

            self.present(navCont!, animated: true, completion: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(self.showCollege(_:)), name: NSNotification.Name(rawValue: "selectedCollege"), object: nil)
            return false

        } else if textField == self.cityTextField {
            
            let navController = self.storyboard?.instantiateViewController(withIdentifier: "cityNavController")

            self.present(navController!, animated: true, completion: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(self.showCity(_:)), name: NSNotification.Name(rawValue: "selectedCity"), object: nil)
            return false
        }
        
        return true
    }
}

