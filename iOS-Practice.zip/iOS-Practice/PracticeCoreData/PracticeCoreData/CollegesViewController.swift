//
//  CollegesViewController.swift
//  PracticeCoreData
//
//  Created by Pavan on 12/10/1939 Saka.
//  Copyright © 1939 Pavan. All rights reserved.
//

import UIKit
import CoreData

class CollegesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var collegeList = [College]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getColleges()
    }
    
    func getColleges() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "College")
        
        do {
            self.collegeList = try managedContext.fetch(fetchRequest) as! [College]
            self.tableView.reloadData()
        } catch let error as Error {
            print("\(error.localizedDescription)")
        }
    }

    @IBAction func closeView(_ sender: Any) {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension CollegesViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.collegeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "collegesCell", for: indexPath)
        let aCollege = self.collegeList[indexPath.row]
        cell.textLabel?.text = aCollege.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let aCollege = self.collegeList[indexPath.row]
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "selectedCollege"), object: nil, userInfo: ["college":aCollege])
        self.navigationController?.dismiss(animated: true, completion: nil)        
        
    }
}


