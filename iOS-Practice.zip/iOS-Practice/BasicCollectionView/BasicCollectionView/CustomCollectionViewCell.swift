//
//  CustomCollectionViewCell.swift
//  BasicCollectionView
//
//  Created by pavan chowdary on 16/12/17.
//  Copyright © 2017 innData. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var detailsLbl: UILabel!
}
