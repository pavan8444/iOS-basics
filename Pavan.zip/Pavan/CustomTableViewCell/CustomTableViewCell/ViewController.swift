//
//  ViewController.swift
//  CustomTableViewCell
//
//  Created by Gangadhar on 12/12/17.
//  Copyright © 2017 Gangadhar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    let studentsArray : [[String:String]] = [["name":"Ramesh", "course":"DotNet", "imageUrl":""], ["name":"Kishore", "course":"JAVA", "imageUrl":""], ["name":"Hari", "course":"JAVA", "imageUrl":""]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Mark - TableView Methodst
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.studentsArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath) as! CustomTableViewCell
        
        let aStudent = studentsArray[indexPath.row]
        cell.nameLbl.text = aStudent["name"]
        cell.courseLbl.text = aStudent["course"]
        cell.imgView.image = UIImage(named: "placeholder")
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let aStudent = studentsArray[indexPath.row]
        let detailsView = self.storyboard?.instantiateViewController(withIdentifier: "detailsView") as! DetailsViewController
        detailsView.studentData = aStudent
        
        self.navigationController?.pushViewController(detailsView, animated: true)
        
    }

}



